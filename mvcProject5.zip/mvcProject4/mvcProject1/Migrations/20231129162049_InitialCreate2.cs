﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace mvcProject1.Migrations
{
    public partial class InitialCreate2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
